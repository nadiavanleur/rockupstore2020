# WPGraphQL for Custom Post Type UI

Install this plugin along with WPGraphQL and Custom Post Type UI and you will have settings to show your Custom Post Types and Custom Taxonomies in GraphQL.
